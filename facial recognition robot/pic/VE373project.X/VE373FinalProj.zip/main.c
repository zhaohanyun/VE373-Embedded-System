#include<p32xxxx.h>
#include"global.h"
#include <p32xxxx.h>
#include <proc/p32mx795f512l.h>
#include<sys\kmem.h>

u8 Start[5] = "start";
//void main() {
//    
//    CLK_INIT();
//    UART2_INIT();
//    motorset[0]=50;
//    motorset[1]=50;
//    motorset[2]=50;
//    motorset[3]=50;
//    SentToSTM();
//    while (1);
////    while(1) {
////        SentToSTM();
////        int i;
////        for (i=0;i<100000;++i) {}
////    }
//}
void main() { 
    TRISDbits.TRISD0 = 0;
    TRISDbits.TRISD1 = 0;
    TRISDbits.TRISD2 = 0;
    PORTDbits.RD2 = 0;
    PORTDbits.RD0 = 0;
    PORTDbits.RD1 = 0;
    CLK_INIT();
    UART1_INIT();
    DMA_INIT(Start);
    while (1) {
        register int pollCnt;       //use a poll counter
        static int cnt = Size-1;
        pollCnt = 200;              //use an adjusted value
        while (pollCnt--);          //wait before reading again the DMA controller
        if (DCH0INTbits.CHCCIF && cnt!=0)
        {
            DCH0INTbits.CHCCIF = 0;
            IFS1bits.DMA0IF = 0;
            cnt--;
            DCH0DSA = KVA_TO_PA(&U1TXREG);
            DCH0ECONbits.CFORCE = 1; //initiate a transfer
        }
    }
}  